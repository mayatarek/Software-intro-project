using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SWD_project.Pages
{
    public class shopModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
