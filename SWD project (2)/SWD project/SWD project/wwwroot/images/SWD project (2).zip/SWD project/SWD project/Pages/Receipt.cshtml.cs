using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SWD_project.Pages
{
    public class ReceiptModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
