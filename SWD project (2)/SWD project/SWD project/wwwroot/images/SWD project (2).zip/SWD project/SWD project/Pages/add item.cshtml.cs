using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SWD_project.Pages
{
    public class add_orderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
