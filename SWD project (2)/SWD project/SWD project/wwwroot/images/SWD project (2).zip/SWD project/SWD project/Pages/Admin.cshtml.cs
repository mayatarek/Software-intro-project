using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SWD_project.Pages
{
    public class Admin_pageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
